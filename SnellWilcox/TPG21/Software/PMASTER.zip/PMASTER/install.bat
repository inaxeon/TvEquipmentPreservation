cd pmsetup
setup
pause
cd ..
copy *.* C:\PMASTER
copy "Pattern Master.lnk" "C:\Documents and Settings\All Users\Desktop"
