This is the Pattern Master Service Release 1.

This release contains only bug fixes. In addition, it contains support drivers to enable Pattern Master
to operate in MS Windows NT4, Windows 2000, and Windows XP.


Installation Instructions
-------------------------
Copy all files to the Pattern Master Installation directory. 

For Windows '95, 98, run PMASTER.EXE as before.

For Windows NT4, W2K or XP, run PMASTER_NT_W2K_XP.BAT


Special Information for NT4, W2K and XP users
---------------------------------------------

The menu "Tranfer->Configuration" allows the user to select the parallel port for downloading data to the TPG.
The port numbers are notional and may not match the exact port numbering within the BIOS. Pattern Master assumes
the following:

LPT1 base address is 0x378
LPT2 base address is 0x278
LPT3 base address is 0x3BC
LPT4 base address is 0x2BC

If your PC configuration is different from the above, simply select the LPT port that matches the base address 
of the port you wish to use.


Extra info for XP
-----------------

Set compatability of batch file or PMASTER.EXE to 'Windows NT 4.0'.








